Open CarPool
============

Web application for offering and requesting lifts by car to and from work.
Open source project initiated by the eBay Green team. Based on a copy of the
OCP production server at eBay from January 2014.
