<?php

require_once '../functions/functions.php';

smarty_display('feedback');

?>